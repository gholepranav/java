package org.pranav.springboot1.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
/*@ComponentScan("org.pranav.springboot1.controller")*/
public class SpringBootMain {

	public static void main(String[] args) {
		SpringApplication app = new SpringApplication(SpringBootMain.class);
		app.run(args);
	}

}
