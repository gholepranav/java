package org.pranav.springboot1.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class Welcome {
	@GetMapping("/")
	public String index(@RequestParam(name="fname", required=false,defaultValue="world") String name, Model model) {
		model.addAttribute("name", name);
		return "index";
	}
	@GetMapping("/greeting")
	public String greet(@RequestParam(name="fname", required=false,defaultValue="world") String name, Model model) {
		model.addAttribute("name", name);
		return "greet";
	}

}
