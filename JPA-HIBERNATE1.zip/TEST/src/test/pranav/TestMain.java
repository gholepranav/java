package test.pranav;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import test.pranav.jpabeans.Actor;
import test.pranav.jpabeans.Movies;
import test.pranav.jpabeans.Rating;

public class TestMain {

	public static void main(String[] args) {
		/*String s1 = "Aa";
		String s2 =  new String("Aa");
		
		System.out.println(s1.hashCode() + " |\\| " +s2.hashCode() + " |\\| " + (s1==s2) + " |\\| " + s1.equals(s2));*/
		
		List<Actor> actors = new ArrayList<>();
		Actor a = new Actor();
		a.setName("Ajay Devgan");
		
		
		Actor a1 = new Actor();
		a1.setName("Arshad Warsi");
		
		actors.add(a); actors.add(a1);
		Rating r = new Rating();
		r.setRatingStars(5L);
		
		
		Movies m = new Movies();
		
		m.setName("Golmaal-3");
		m.setReleaseDate(new Date());
		m.setActors(actors);
		m.setRating(r);
		
		PersistenceManager pM = new PersistenceManager();
		
		EntityManager em = pM.getEntityManager();
		
		em.getTransaction().begin();
		em.persist(a);
		em.persist(a1);
		em.persist(r);
		em.persist(m);
		em.getTransaction().commit();
		
		/*Movies findM = 
				em.find(Movies.class, 1L);
		
		System.out.println("ID: "+findM.getId());
		System.out.println("Name: "+findM.getName());
		System.out.println("Release Date: " + findM.getReleaseDate());
		System.out.println("Rating: "+ findM.getRating().getRatingStars());
		List<Actor> acList1 = findM.getActors();
		for (Actor actor : acList1) {
			System.out.println("Actor: "+actor.getName());
		}*/
		
		/*List <Movies> l1 = em.createQuery("from Movies Where name =:name").setParameter("name", "Golmaal").getResultList();
		
		for (Movies movies : l1) {
			System.out.println("ID: "+movies.getId());
			System.out.println("Name: "+movies.getName());
			System.out.println("Release Date: " + movies.getReleaseDate());
			System.out.println("Rating: "+ movies.getRating().getRatingStars());
			List<Actor> acList2 = movies.getActors();
			for (Actor actor : acList2) {
				System.out.println("Actor: "+actor.getName());
			}
			//System.out.println("Actor: " + movies.getActors());
		}*/
		
		
		/*System.out.println(findM.toString());*/
		
		pM.closeEntityManagerFactory();
		
	}

}