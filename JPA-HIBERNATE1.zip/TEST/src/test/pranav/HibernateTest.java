package test.pranav;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import test.pranav.jpabeans.Actor;
import test.pranav.jpabeans.Movies;

public class HibernateTest {

	public static void main(String[] args) {
		Configuration configuration = new Configuration();
		configuration.configure("hibernate-annotation.cfg.xml");
		
		ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
    	System.out.println("Hibernate Annotation serviceRegistry created");
    	
    	SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
    	Session session = sessionFactory.getCurrentSession();
    	Transaction tx = session.beginTransaction();
    	
    	
    	List<Movies> movies = session.createQuery("from Movies").list();
    	
    	
    	
    	for (Movies movies2 : movies) {
    		System.out.println("ID: "+movies2.getId());
    		System.out.println("Name: "+movies2.getName());
    		System.out.println("Release Date: " + movies2.getReleaseDate());
    		System.out.println("Rating: "+ movies2.getRating().getRatingStars());
    		List<Actor> acList1 = movies2.getActors();
    		for (Actor actor : acList1) {
    			System.out.println("Actor: "+actor.getName());
    		}
    		System.out.println("-------+++++-------");
		}
    	
    	/*Movies m =	(Movies) session.get(Movies.class, 1L);
    	System.out.println("ID: "+m.getId());
		System.out.println("Name: "+m.getName());
		System.out.println("Release Date: " + m.getReleaseDate());
		System.out.println("Rating: "+ m.getRating().getRatingStars());
		List<Actor> acList1 = m.getActors();
		for (Actor actor : acList1) {
			System.out.println("Actor: "+actor.getName());
		}*/
    	
		tx.commit();
		//session.close();
		sessionFactory.close();
	}

}
