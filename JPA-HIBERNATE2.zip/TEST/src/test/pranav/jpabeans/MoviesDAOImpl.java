package test.pranav.jpabeans;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class MoviesDAOImpl extends HibernateDAO implements MoviesDAO {
	@Override
	public Movies saveMovie(Movies m) {
		try {
			Session session = getHibernateSessionFactory().getCurrentSession();
			Transaction tx = session.getTransaction();
			tx.begin();
			session.save(m);
			tx.commit();
			this.closeSessionFactory();
		} catch (HibernateException e) {
			e.printStackTrace();
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return m;
	}

	@Override
	public Actor saveActor(Actor a) {
		try {
			Session session = getHibernateSessionFactory().getCurrentSession();
			Transaction tx = session.getTransaction();
			tx.begin();
			session.save(a);
			tx.commit();
			this.closeSessionFactory();
		} catch (HibernateException e) {
			e.printStackTrace();
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return a;
	}

	@Override
	public Rating saveRating(Rating r) {
		try {
			Session session = getHibernateSessionFactory().getCurrentSession();
			Transaction tx = session.getTransaction();
			tx.begin();
			session.save(r);
			tx.commit();
			this.closeSessionFactory();
		} catch (HibernateException e) {
			e.printStackTrace();
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return r;
	}

	@Override
	public void closeSessionFactory() {
		super.closeSessionFactory();
	}

	@Override
	public List<Movies> getAllMoviesList() {
		Session session;
		List<Movies> movies = null;
		try {
			session = getHibernateSessionFactory().getCurrentSession();
			Transaction tx = session.getTransaction();
			tx.begin();
			movies = session.createQuery("from Movies").list();
			for (Movies movies2 : movies) {
	    		System.out.println("ID: "+movies2.getId());
	    		System.out.println("Name: "+movies2.getName());
	    		System.out.println("Release Date: " + movies2.getReleaseDate());
	    		System.out.println("Rating: "+ movies2.getRating().getRatingStars());
	    		List<Actor> acList1 = movies2.getActors();
	    		for (Actor actor : acList1) {
	    			System.out.println("Actor: "+actor.getName());
	    		}
	    		System.out.println("-------+++++-------");
			}
			tx.commit();
			this.closeSessionFactory();
		} catch (HibernateException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return movies;
	}

	@Override
	public Actor getActorByName(String name) {
		Actor a = null;
		Session session;
		try {
			session = getHibernateSessionFactory().getCurrentSession();
			Transaction tx = session.getTransaction();
			tx.begin();
			a = (Actor) session.createQuery("from Actor where name=:name").setParameter("name", name).uniqueResult();
			tx.commit();
			this.closeSessionFactory();
		} catch (HibernateException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return a;
	}
}
