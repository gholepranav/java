package test.pranav.jpabeans;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

//import javax.persistence.*;

@Entity
public class Actor extends Artist /*implements Serializable */{
	/**
	 * 
	 */

	@ManyToMany(mappedBy="actors", fetch=FetchType.EAGER)
	List<Movies> movies;
	
	public List<Movies> getMovies() {
		return movies;
	}

	public void setMovies(List<Movies> movies) {
		this.movies = movies;
	}

	@Override
	public String toString() {
		return "Actor [movies=" + movies + "]";
	}
	
}
