package test.pranav.jpabeans;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class HibernateDAO {
	public static SessionFactory sessionFactory=null;
	public SessionFactory getHibernateSessionFactory() throws Exception{
		if(sessionFactory==null) {
		Configuration configuration = new Configuration();
		configuration.configure("hibernate-annotation.cfg.xml");
		
		ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
    	System.out.println("Hibernate Annotation serviceRegistry created");
    	
    	sessionFactory = configuration.buildSessionFactory(serviceRegistry);
    	return sessionFactory;
		} else {
			return sessionFactory;
		}
	}
	
	public void closeSessionFactory() {
		sessionFactory.close();
		sessionFactory = null;
	}
}
