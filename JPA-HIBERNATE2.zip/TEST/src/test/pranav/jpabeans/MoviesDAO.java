package test.pranav.jpabeans;

import java.util.List;

public interface MoviesDAO {
	Movies saveMovie(Movies m);
	Actor saveActor(Actor a);
	Rating saveRating(Rating r);
	List<Movies> getAllMoviesList();
	Actor getActorByName(String name);
}
