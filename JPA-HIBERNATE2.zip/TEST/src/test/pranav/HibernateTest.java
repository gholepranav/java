package test.pranav;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import test.pranav.jpabeans.Actor;
import test.pranav.jpabeans.Movies;
import test.pranav.jpabeans.MoviesDAO;
import test.pranav.jpabeans.MoviesDAOImpl;
import test.pranav.jpabeans.Rating;

public class HibernateTest {

	public MoviesDAO moviesDAO = new MoviesDAOImpl();
	
	public static void main(String[] args) {
		/*Configuration configuration = new Configuration();
		configuration.configure("hibernate-annotation.cfg.xml");
		
		ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
    	System.out.println("Hibernate Annotation serviceRegistry created");
    	
    	SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
    	Session session = sessionFactory.getCurrentSession();
    	Transaction tx = session.beginTransaction();*/
		
		HibernateTest ht = new HibernateTest();
		
		List<Actor> actors = new ArrayList<>();
		Actor a = ht.moviesDAO.getActorByName("Ajay Devgan");
		if(a == null) {
			a  = new Actor();
			a.setName("Ajay Devgan");
			ht.moviesDAO.saveActor(a);
		}
		Actor a1 = ht.moviesDAO.getActorByName("Arshad Warsi");
		if(a1 == null) {
			a1 = new Actor();
			a1.setName("Arshad Warsi");
			ht.moviesDAO.saveActor(a1);
		}
		
		actors.add(a); actors.add(a1);
		
		Rating r = new Rating();
		r.setRatingStars(5L);
		
		ht.moviesDAO.saveRating(r);
		
		
		Movies m = new Movies();
		
		m.setName("Golmaal");
		m.setReleaseDate(new Date());
		m.setActors(actors);
		m.setRating(r);
		
		ht.moviesDAO.saveMovie(m);
		
    	List<Movies> movies = ht.moviesDAO.getAllMoviesList();
    	
    	
    	
    	/*for (Movies movies2 : movies) {
    		System.out.println("ID: "+movies2.getId());
    		System.out.println("Name: "+movies2.getName());
    		System.out.println("Release Date: " + movies2.getReleaseDate());
    		System.out.println("Rating: "+ movies2.getRating().getRatingStars());
    		List<Actor> acList1 = movies2.getActors();
    		for (Actor actor : acList1) {
    			System.out.println("Actor: "+actor.getName());
    		}
    		System.out.println("-------+++++-------");
		}*/
    	
    	/*Movies m =	(Movies) session.get(Movies.class, 1L);
    	System.out.println("ID: "+m.getId());
		System.out.println("Name: "+m.getName());
		System.out.println("Release Date: " + m.getReleaseDate());
		System.out.println("Rating: "+ m.getRating().getRatingStars());
		List<Actor> acList1 = m.getActors();
		for (Actor actor : acList1) {
			System.out.println("Actor: "+actor.getName());
		}*/
    	
	}

}
