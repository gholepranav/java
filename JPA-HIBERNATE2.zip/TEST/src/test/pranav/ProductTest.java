package test.pranav;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class ProductTest {

	public static void main(String[] args) {
		final java.util.Set<Product> l = new HashSet<>();
		
		l.add(new Product(1,"ABC"));
		l.add(new Product(1,"ABC"));
		l.add(new Product(2,"ABC"));
		
		for (Product product : l) {
			System.out.println(product.id);
			System.out.println(product.name);
		}
		System.out.println(l.toString());
		
		String s1 = "ABC";
		String s2 = "ABC";
		String s3 = new String("ABC");
		Map<String, Integer> m = new HashMap<>();
		
		m.put(s1, 1);
		m.put(s2, 2);
		m.put(s3, 3);
		
		System.out.println(m.size());
	}

}
