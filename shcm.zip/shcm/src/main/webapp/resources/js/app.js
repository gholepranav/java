/**
 * 
 */

$(document).ready(function(){
  $("#descEdit").click(function(){
	  //if($("update").css("display") == "none"){
		//  $("#update").hide();
	  //} else {
		  $("#update").show();
	  //}
  });
  
  $("#save").click(function(){
	  var callURL = $("#callUrl").val();
	 $.ajax({
		url:callURL,
		success: function(result){
			$("#descSpan").text(result);
			$("#update").hide();
		},
	 	type: "POST",
	 	data: {descTA:$("#descTA").val()}
	 });
  });
});