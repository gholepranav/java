package net.pranav.shcm.dao;

import java.util.List;
import java.util.Set;

import net.pranav.shcm.entities.Songs;

public interface SongsDAO {
	public void saveSong(Songs songs);
	public List<Songs> getAllSongs();
	public Songs getSongById(Integer id)throws InterruptedException;
}
