package net.pranav.shcm.dao;

import net.pranav.shcm.entities.Actor;

public interface ActorDAO {
	void saveActor(Actor a);
}
