package net.pranav.shcm.dao;

import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import net.pranav.shcm.entities.Songs;

@Repository
@Scope("session")
public class SongsDAOImpl implements SongsDAO {
	static int count = 0;
	public SongsDAOImpl() {
		count++;
		System.out.println(this.getClass().getName() + " :: " +count);
	}
	@Autowired
	SessionFactory sessionFactory;
	@Transactional
	public void saveSong(Songs songs) {
		Session session = sessionFactory.getCurrentSession();
		session.save(songs);
		//return songs;
	}

	@Transactional
	public List<Songs> getAllSongs() {
		Session session = sessionFactory.getCurrentSession();
		List<Songs> listOfSongs = session.createQuery("from Songs").list();
		
		return listOfSongs;
	}
	
	@Transactional
	public Songs getSongById(Integer id) throws InterruptedException {
		Session session = sessionFactory.getCurrentSession();
		Songs songs = (Songs) session.get(Songs.class, id);
		System.out.println("LINE 1 :: "+songs.getId() + " " + songs.getSongName() + " "+ songs.getLength()+ " "+session.contains(songs));
		//session.delete(songs);
		//System.out.println("LINE 2 :: "+songs.getId() + " " + songs.getSongName() + " "+ songs.getLength()+ " "+session.contains(songs));
		//session.delete(songs);
		//System.out.println("LINE 2 :: "+songs.getId() + " " + songs.getSongName() + " "+ songs.getLength()+ " "+session.contains(songs));
		//session.save(songs);
		return songs;
	}

}
