package net.pranav.shcm.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import net.pranav.shcm.dao.MoviesDAO;
import net.pranav.shcm.dao.SongsDAO;
import net.pranav.shcm.entities.Movies;
import net.pranav.shcm.entities.Songs;

@Controller
public class SongsController {
	
	@Autowired
	SongsDAO songsDAO;
	
	@RequestMapping(value="/allSongs", method= {RequestMethod.GET})
	public String allSongs(ModelMap model) {
		List<Songs> s = songsDAO.getAllSongs();
		model.addAttribute("songsList", s);
		return "allSongs";
	}
	
	@RequestMapping(value="/addSong", method= {RequestMethod.POST})
	public String addSong(HttpServletRequest request,HttpServletResponse response,ModelMap map) {
		Songs s =  new Songs();
		s.setSongName(request.getParameter("songName"));
		s.setLength(request.getParameter("songLength"));
		songsDAO.saveSong(s);
		return "redirect:/allSongs";
	}
	
	@RequestMapping(value = "/song/{id}/{name}", method=RequestMethod.GET)
	public String songDetails(@PathVariable
								Integer id, @PathVariable String name,ModelMap map) throws InterruptedException {
		Songs s = songsDAO.getSongById(id);
		map.addAttribute("songId", s);
		return "redirect:/allSongs";
	}
}
