package net.pranav.shcm.entities;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Movies implements Serializable{
	
	private static final long serialVersionUID = 3794495685212821038L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	private String movieName;
	@ManyToMany(fetch=FetchType.LAZY)
	private Set<Actor> actor;
	private String description;
	
	public Set<Actor> getActor() {
		return actor;
	}
	public void setActor(Set<Actor> actor) {
		this.actor = actor;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "Movies [id=" + id + ", movieName=" + movieName + ", actor=" + actor + ", description=" + description
				+ "]";
	}
	
	
}
