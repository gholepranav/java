package net.pranav.shcm.dao;

import java.util.List;

import net.pranav.shcm.entities.Movies;

public interface MoviesDAO {
	void saveMovie(Movies m);
	List<Movies> getAllMovies();
	Movies getMovieById(Integer id);
	Movies updateMovie(Integer id, String descTA);
}
