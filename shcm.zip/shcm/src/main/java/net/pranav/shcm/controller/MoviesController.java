package net.pranav.shcm.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.beans.factory.annotation.Autowired;

import net.pranav.shcm.dao.MoviesDAO;
import net.pranav.shcm.entities.Movies;

@Controller
@RequestMapping
public class MoviesController {
	
	@Autowired
	MoviesDAO moviesDAO;
	@RequestMapping(value = "/movie/{id}/{name}", method=RequestMethod.GET)
	public String moviesDetails(@PathVariable
								Integer id, @PathVariable String name,ModelMap map) {
		Movies m = moviesDAO.getMovieById(id);
		//System.out.println(m);
		map.addAttribute("movieId", m);
		return "moviesDetails";
	}
	
	@RequestMapping(value = "/movie/{id}/addDesc", method=RequestMethod.POST)
	@ResponseBody
	public String addDesc(@PathVariable Integer id, @RequestParam String descTA) {
		Movies m = moviesDAO.updateMovie(id, descTA);
		return m.getDescription();
		
	}
}
