package net.pranav.shcm.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Actor implements Serializable{

	private static final long serialVersionUID = 1216373940502132078L;

	public Actor() {
	}
	
	public Actor(String acorName) {
		this.actorName = acorName;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	private String actorName;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getActorName() {
		return actorName;
	}
	public void setActorName(String actorName) {
		this.actorName = actorName;
	}

	@Override
	public String toString() {
		return "Actor [id=" + id + ", actorName=" + actorName + "]";
	}
	
	
}
