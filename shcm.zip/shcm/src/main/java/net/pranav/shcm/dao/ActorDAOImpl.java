package net.pranav.shcm.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import net.pranav.shcm.entities.Actor;
@Repository

public class ActorDAOImpl implements ActorDAO {
	@Autowired
	protected SessionFactory sessionFactory;
	@Transactional
	public void saveActor(Actor a) {
		sessionFactory.getCurrentSession().persist(a);
	}

}
