package net.pranav.shcm.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import net.pranav.shcm.dao.ActorDAO;
import net.pranav.shcm.dao.MoviesDAO;
import net.pranav.shcm.entities.Actor;
import net.pranav.shcm.entities.Movies;

@Controller
public class InitController {
	@Autowired(required=true)
	MoviesDAO moviesDAO;
	
	@Autowired(required=true)
	ActorDAO actorDAO;
	
	@RequestMapping(value="/", method={RequestMethod.GET})
	public String home(ModelMap map) {
		List<Movies> movies = moviesDAO.getAllMovies();
		System.out.println(movies.size()+ " :: "+movies.toString());
		map.addAttribute("moviesList", movies);
		return "index";
	}
	@RequestMapping(value="/addMovie", method={RequestMethod.POST})
	public String addMovie(HttpServletRequest request,HttpServletResponse response,ModelMap map) {
		Set<Actor> actorSet = new HashSet<Actor>();
		Actor a1 = new Actor(request.getParameter("actorName1"));
		Actor a2 =  new Actor(request.getParameter("actorName2"));
		actorDAO.saveActor(a1);
		actorDAO.saveActor(a2);
		actorSet.add(a1);
		actorSet.add(a2);
		Movies m = new Movies();
		m.setMovieName(request.getParameter("movieName"));
		m.setActor(actorSet);
		moviesDAO.saveMovie(m);
		return "redirect:/";
	}
	
}
