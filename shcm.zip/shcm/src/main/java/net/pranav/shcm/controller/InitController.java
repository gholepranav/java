package net.pranav.shcm.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import net.pranav.shcm.dao.MoviesDAO;
import net.pranav.shcm.entities.Movies;

@Controller
public class InitController {
	@Autowired
	MoviesDAO moviesDAO;
	
	@RequestMapping(value="/", method={RequestMethod.GET})
	public String home(ModelMap map) {
		List<Movies> movies = moviesDAO.getAllMovies();
		map.addAttribute("moviesList", movies);
		return "index";
	}
	@RequestMapping(value="/addMovie", method={RequestMethod.GET})
	public String addMovie(HttpServletRequest request,HttpServletResponse response,ModelMap map) {
		Movies m = new Movies();
		m.setMovieName(request.getParameter("movieName"));
		moviesDAO.saveMovie(m);
		return "redirect:/";
	}
	
}
