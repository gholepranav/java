package net.pranav.shcm.exception;

public class CustomDbException extends Exception {
	public CustomDbException() {
		super();
	}
	
	public CustomDbException(String s) {
		super(s);
	}
	
	@Override
	public void printStackTrace() {
		super.printStackTrace();
	}
}
