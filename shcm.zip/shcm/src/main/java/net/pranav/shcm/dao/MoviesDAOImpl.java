package net.pranav.shcm.dao;

import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import net.pranav.shcm.entities.Actor;
import net.pranav.shcm.entities.Movies;
import net.pranav.shcm.exception.CustomDbException;

@Repository

public class MoviesDAOImpl implements MoviesDAO {
	@Autowired
	protected SessionFactory sessionFactory;
	@Transactional
	public void saveMovie(Movies m) {
		try {
			sessionFactory.getCurrentSession().persist(m);
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	@Transactional
	public List<Movies> getAllMovies() {
		List<Movies> listOfMovies = null;
		List<Movies> listOfMoviesWithActor = null;

		try {
			Query query = sessionFactory.getCurrentSession().createQuery("from Movies");
			listOfMovies = query.list();
			for (int i = 0; i < listOfMovies.size(); i++) {
				Movies movie = listOfMovies.get(i);
				System.out.println(movie.getActor());
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return listOfMovies;
	}


	@Transactional
	public Movies getMovieById(Integer id) {
		Movies m = null;
		try {
			m = (Movies) sessionFactory.getCurrentSession().get(Movies.class, id);
			if(m==null) {
				throw new CustomDbException("Movie Not Available.");
			} else {
				System.out.println(m.getActor());
			}
		
		} catch (CustomDbException e) {
			e.printStackTrace();
		}
		
		return m;
	}
	
	

}
