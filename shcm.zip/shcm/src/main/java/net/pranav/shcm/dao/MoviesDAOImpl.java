package net.pranav.shcm.dao;

import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import net.pranav.shcm.entities.Actor;
import net.pranav.shcm.entities.Movies;
import net.pranav.shcm.exception.CustomDbException;

@Repository

public class MoviesDAOImpl implements MoviesDAO {
	@Autowired
	protected SessionFactory sessionFactory;
	@Transactional
	public void saveMovie(Movies m) {
		try {
			sessionFactory.getCurrentSession().persist(m);
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	@Transactional
	public List<Movies> getAllMovies() {
		List<Movies> listOfMovies = null;
		List<Movies> listOfMoviesWithActor = null;

		try {
			Query query = sessionFactory.getCurrentSession().createQuery("from Movies");
			listOfMovies = query.list();
			for (int i = 0; i < listOfMovies.size(); i++) {
				Movies movie = listOfMovies.get(i);
				System.out.println(movie.getActor());
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return listOfMovies;
	}


	@Transactional
	public Movies getMovieById(Integer id) {
		Movies m = null;
		Session session = sessionFactory.getCurrentSession();
		try {
			m = (Movies) session.get(Movies.class, id);
			
			Set<Actor> as = m.getActor();
			System.out.println("Movie state :: "+session.contains(m) + " Actor state :: "+session.contains(as));
			
			session.delete(m);
			session.clear();
			for (Actor actor : as) {
				session.save(actor);
			}
			session.save(m);
			if(m==null) {
				throw new CustomDbException("Movie Not Available.");
			} else {
				System.out.println(m.getActor());
			}
		
		} catch (CustomDbException e) {
			System.out.println(e.getMessage());
		}
		
		return m;
	}

	@Transactional
	public Movies updateMovie(Integer id, String descTA) {
		Session session = sessionFactory.getCurrentSession();
		Movies m = (Movies) session.get(Movies.class, id);
		m.setDescription(descTA);
		m = (Movies) session.merge(m);
		return m;
	}
	
	

}
