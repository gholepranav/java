package testinger;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class MainSingleton {

	
	public static void main(String[] args) throws CloneNotSupportedException, NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		/* Singleton class with cloning
		SingletonClass i1 = new SingletonClass();
		
		SingletonClass i2 = (SingletonClass) i1.clone();
		
		i1.s = "first";
		
		i2.s = "second";
		System.out.println(i1.s);
		
		System.out.println(i2.s);*/
		
		/*Singleton with reflection*/
		
		/*SingletonClass s1 = SingletonClass.getInstance();
		Constructor c1 = SingletonClass.class.getDeclaredConstructor(new Class[0]);
		c1.setAccessible(true);
		SingletonClass s2 = (SingletonClass) c1.newInstance();
		
		s1.s = "oldinstance";
		s2.s= "newinstance";
		
		System.out.println(s1.s);
		System.out.println(s2.s);*/
		
		
		/*SingletonClass with enum*/
		
		SingletonWEnum s1 = SingletonWEnum.INSTANCE;
		
		s1.setS("myinstance");
		
		SingletonWEnum s2 =SingletonWEnum.INSTANCE;
		
		s2.setS("yourinstance");
		
		System.out.println(s1.getS());
		
		System.out.println(s2.getS());
		
	}
}
