package testinger;

public class SingletonChild/* extends SingletonClass */implements Cloneable {
	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

}
