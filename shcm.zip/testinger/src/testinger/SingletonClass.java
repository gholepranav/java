package testinger;

public final class SingletonClass {
	private static SingletonClass instance = null;
	public String s;
	private SingletonClass() {
		s  = "abcd";
	}
	public static SingletonClass getInstance() {
		instance = new SingletonClass();
		return instance;
	}
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException();
	}
}
