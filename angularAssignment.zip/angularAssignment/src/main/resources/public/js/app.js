var app = angular.module('angularAssignment',["ngRoute"]);
/*router*/

app.config(function($routeProvider){
	$routeProvider
	.when("/add",{
		templateUrl : "addEmployee.html"
	})
	//$routeProvider
	.when("/showAllEmployee",{
		templateUrl : "showAllEmployee.html"
	})
	//$routeProvider
	.when("/updateEmployee/:employee",{
		templateUrl : "updateEmployee.html"
	})
});

/*Angular Services*/
app.service('emailVerificationService', function($http) {
	this.emailValidator = function(employee) {
		var employeeEmailIdStr = employee.employeeEmail;
		//alert(employeeEmailIdStr);
		$http.get('http://localhost:8082/api/employee/emailVerificvation/'+employeeEmailIdStr)
		.then(function(response) {
			//alert(response.data.message);
			var message = response.data.message;
			return message;
		});
	}
});

/* Controllers */
app.controller('showAll', function($scope, $http) {
	$http.get('http://localhost:8082/api/employee/showAll')
	.then( function(response) {
		$scope.employee = response.data;
	});
});
app.controller('employeeController', function($scope, $http, emailVerificationService) {
	$scope.emailVerification = function(employee) {
		var check = emailVerificationService.emailValidator(employee);
		if( check == true) {
			alert(check);
			$scope.verificationMessage = "This email Id already exist. Please try again.";
		}
	};
	
	$scope.saveEmployee = function(employee) {
		//alert(employee.salary);
		$http.post('http://localhost:8082/api/employee/saveEmployee',employee)
		.then(function(response){
			if(response.data.message!=undefined) {
				if(response.data.message===1) {
					$scope.message = "Data saved successfully.";
				} else if(response.data.message===0) {
					$scope.message = "Something went wrong! Please try again.";
				}
			} 
		});
	};
});
app.controller('employeeEdit', function($scope, $http, $routeParams) {
	var empId = $routeParams.employee;
	//alert(empId);
	$http.get('http://localhost:8082/api/employee/getEmployee/'+empId)
	.then(function(response) {
		//alert(response.data.employeeName);
		$scope.employee=response.data;
	});
	$scope.updateEmployee = function(employee) {
		//alert(response.data.id);
		$http.post('http://localhost:8082/api/employee/updateEmployee',employee)
		.then(function(response){
			if(response.data.message!=undefined) {
				if(response.data.message===1) {
					$scope.message = "Data updated successfully.";
				} else if(response.data.message===0) {
					$scope.message = "Something went wrong! Please try again.";
				}
			} 
		});
	};
});

