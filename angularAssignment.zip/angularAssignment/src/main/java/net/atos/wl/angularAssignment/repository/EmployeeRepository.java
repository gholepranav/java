package net.atos.wl.angularAssignment.repository;

import org.springframework.data.repository.CrudRepository;

import net.atos.wl.angularAssignment.entities.*;

public interface EmployeeRepository extends CrudRepository<Employee, Integer> {

}
