package net.atos.wl.angularAssignment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import net.atos.wl.angularAssignment.entities.Employee;
import net.atos.wl.angularAssignment.repository.EmployeeRepository;

@Controller
public class WebController {
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@RequestMapping("/")
	public String indexView() {
		return "index";
	}
	
	/*
	 * @GetMapping(path = "/addEmployee")
	 * 
	 * public @ResponseBody String addEmployee() { Employee emp = new Employee();
	 * 
	 * emp.setEmployeeName("Pranav"); emp.setEmployeeEmail("pranav@atos.net");
	 * emp.setSalary(1000000F);
	 * 
	 * employeeRepository.save(emp);
	 * 
	 * return "saved"; }
	 */
}
