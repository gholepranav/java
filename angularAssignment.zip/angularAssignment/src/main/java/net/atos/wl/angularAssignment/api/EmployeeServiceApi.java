package net.atos.wl.angularAssignment.api;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.util.JSONPObject;

import net.atos.wl.angularAssignment.entities.Employee;
import net.atos.wl.angularAssignment.repository.EmployeeRepository;

@RestController
@RequestMapping("/api/employee")
public class EmployeeServiceApi {
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@GetMapping("/showAll")
	public @ResponseBody Iterable<Employee> showAll() {
		System.out.println(EmployeeServiceApi.class.getName() + " showAll");
		return employeeRepository.findAll();
	}

	@PostMapping("/saveEmployee")
	public @ResponseBody String saveEmployee(@RequestBody Employee employee) {
		String result = "";
		try {
			System.out.println(employee.toString());
			employeeRepository.save(employee);
			return "{" + "\"message\":" + 1 + "}";
		} catch (Exception e) {
			e.printStackTrace();
			return "{" + "\"message\":" + 0 + "}";
		}
	}
	
	@GetMapping("/getEmployee/{empId}")
	public @ResponseBody Employee getEmployeeById(@PathVariable Integer empId){
		Optional<Employee> emp = employeeRepository.findById(empId);
		if(emp.isPresent()) {
			Employee e = emp.get();
			return e;
		} else {
			return null;
		}
	}
	
	@PostMapping("/updateEmployee")
	public @ResponseBody String updateEmployee(@RequestBody Employee employee) {
		String result = "";
		System.out.println("::::"+employee.toString());
		try {
			if(employeeRepository.existsById(employee.getId())) {
				employeeRepository.save(employee);
				return "{" + "\"message\":" + 1 + "}";
			} else {
				return "{" + "\"message\":" + 0 + "}";
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			return "{" + "\"message\":" + 0 + "}";
		}
	}
	
	@GetMapping("/emailVerificvation/{emailId}")
	public @ResponseBody String emailVerification(@PathVariable String emailId) {

		System.out.println(":::::: " + emailId);

		Iterable<Employee> iterableEmployees = employeeRepository.findAll();
		boolean check = false;
		List<Employee> empList = new ArrayList<>();

		iterableEmployees.forEach(emp -> empList.add(emp));
		check = empList.stream().anyMatch(emp -> 
				emp.getEmployeeEmail().equals(emailId));

		return "{" + "\"message\":" + check + "}";
	}
}
