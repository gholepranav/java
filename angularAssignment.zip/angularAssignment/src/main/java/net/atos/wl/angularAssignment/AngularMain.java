package net.atos.wl.angularAssignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"net.atos.wl.angularAssignment"})
public class AngularMain {

	public static void main(String[] args) {
		SpringApplication.run(AngularMain.class, args);
	}

}
