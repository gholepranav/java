package test.pranav;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class PersistenceManager {
	final private EntityManagerFactory eMF = Persistence.createEntityManagerFactory("movies-db");
	
	public EntityManager getEntityManager() {
		return eMF.createEntityManager();
	}
	
	void closeEntityManagerFactory() {
		if(eMF.isOpen()) {
			eMF.close();
		}
	}
}
