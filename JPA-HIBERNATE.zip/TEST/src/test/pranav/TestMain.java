package test.pranav;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import test.pranav.jpabeans.Movies;

public class TestMain {

	public static void main(String[] args) {
		/*String s1 = "Aa";
		String s2 =  new String("Aa");
		
		System.out.println(s1.hashCode() + " |\\| " +s2.hashCode() + " |\\| " + (s1==s2) + " |\\| " + s1.equals(s2));*/
		
		Movies m = new Movies();
		
		m.setName("Golmaal-2");
		m.setReleaseDate(new Date());
		
		PersistenceManager pM = new PersistenceManager();
		
		EntityManager em = pM.getEntityManager();
		em.getTransaction().begin();
		em.persist(m);
		em.getTransaction().commit();
		
		Movies findM = 
				em.find(Movies.class, 1L);
		
		List <Movies> l1 = em.createQuery("from Movies").getResultList();
		
		
		System.out.println(l1.toString());
		
		
		System.out.println(findM.toString());
		
		
		em.
		pM.closeEntityManagerFactory();
		
	}

}