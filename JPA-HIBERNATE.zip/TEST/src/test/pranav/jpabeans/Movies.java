package test.pranav.jpabeans;

//import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;
@Entity
public class Movies /*implements Serializable */{
	
	/**
	 * 
	 */
	//private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	private String name;
	private Date releaseDate;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}
	
	@Override
	public String toString() {
		return "[ ID: " + this.id + "] [ Name: " + this.name + "] [ Release Date: " + this.releaseDate +"]";
	}
}
