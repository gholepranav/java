package test.pranav.jpabeans;

public class MoviesActor {
}
