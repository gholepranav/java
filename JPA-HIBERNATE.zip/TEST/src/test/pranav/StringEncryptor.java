package test.pranav;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class StringEncryptor {
	static List<String> alphabets = new ArrayList<>();
	static {
		for(char ch= 'a'; ch <= 'z'; ch++) {
			alphabets.add(String.valueOf(ch));
		}
	}
	
	public static void main(String[] args) {
		System.out.println(alphabets);
		
		String originalString = args[0];
		String encryptedString = encryptString(originalString);
		String decryptedString = decryptString(encryptedString);
		System.out.println(encryptedString);
		System.out.println(decryptedString);
	}

	private static String decryptString(String encryptedString) {
		StringBuffer sb = new StringBuffer(encryptedString);
		sb.reverse();
		String temp = sb.toString();
		StringBuffer decryptedStr = new StringBuffer();
		return null;
	}

	private static String encryptString(String originalString) {
		StringBuffer sb = new StringBuffer(originalString);
		sb.reverse();
		String temp = sb.toString();
		StringBuffer encryptedStr = new StringBuffer();
		for(int i=0; i< temp.length(); i++) {
			char ch = temp.charAt(i);
			int index = alphabets.indexOf(String.valueOf(ch));
			
			int encryptedCharIndex = index + (i);
			
			if(encryptedCharIndex<=alphabets.size()) {
				encryptedStr.append(alphabets.get(encryptedCharIndex));
			} else {
				int a =encryptedCharIndex - alphabets.size();
				encryptedStr.append(alphabets.get(a - 1));
			}
		}
		return encryptedStr.reverse().toString();
	}

}
