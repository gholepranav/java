package org.pranav.springboot2.entities;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class ProductCost {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	Integer id;
	
	@OneToOne
	Product product;
	
	@OneToMany
	List<Overheads> overhead;
	
	String productName;
	
	Float productSellingPrice;
	
	Float productActualPrice;
	
	Float profitPercentage;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public List<Overheads> getOverhead() {
		return overhead;
	}

	public void setOverhead(List<Overheads> overhead) {
		this.overhead = overhead;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Float getProductSellingPrice() {
		return productSellingPrice;
	}

	public void setProductSellingPrice(Float productSellingPrice) {
		this.productSellingPrice = productSellingPrice;
	}

	public Float getProductActualPrice() {
		return productActualPrice;
	}

	public void setProductActualPrice(Float productActualPrice) {
		this.productActualPrice = productActualPrice;
	}

	public Float getProfitPercentage() {
		return profitPercentage;
	}

	public void setProfitPercentage(Float profitPercentage) {
		this.profitPercentage = profitPercentage;
	}
}
