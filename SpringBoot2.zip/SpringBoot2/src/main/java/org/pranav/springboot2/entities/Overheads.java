package org.pranav.springboot2.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Overheads {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	Integer id;
	
	String overHeadType;
	
	Float overheadCost;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getOverHeadType() {
		return overHeadType;
	}

	public void setOverHeadType(String overHeadType) {
		this.overHeadType = overHeadType;
	}

	public Float getOverheadCost() {
		return overheadCost;
	}

	public void setOverheadCost(Float overheadCost) {
		this.overheadCost = overheadCost;
	}
	
}
