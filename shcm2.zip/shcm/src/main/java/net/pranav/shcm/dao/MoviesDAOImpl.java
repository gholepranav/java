package net.pranav.shcm.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import net.pranav.shcm.entities.Movies;

public class MoviesDAOImpl implements MoviesDAO {
	
	@Autowired
	SessionFactory sessionFactory;

	public void saveMovie(Movies m) {
		try {
			sessionFactory.getCurrentSession().persist(m);
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	public List<Movies> getAllMovies() {
		List<Movies> listOfMovies = null;
		try {
			Query query = sessionFactory.getCurrentSession().createQuery("from Movies");
			listOfMovies = query.list();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return listOfMovies;
	}
	
	

}
